Noah McGarry
CIS 233W
Fall 2023

This program meets the requirements of Lab 1, as far as I can tell, because it includes (I believe)
properly structured HTML and JavaScript, one input from the user, one output, it is self-contained,
and it includes two forms of meaningful calculation.

Thank you!